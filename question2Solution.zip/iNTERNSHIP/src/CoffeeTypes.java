import java.util.Scanner;

public class CoffeeTypes {

    String bill = "";
    int total_amount=0;
    int espresso_with_milk =60;
    int espresso_with_cream =75;
    int espresso_with_latte =100;
    int cappucinno_with_milk =80;
    int cappucinno_with_cream =90;
    int cappucinno_with_latte =125;
    int latte_with_milk =100;
    int latte_with_cream =125;
    int latte_with_latte =150;

    int espresso = 1;
    int cappucino = 2;
    int latte = 3;
    int addon_milk = 1;
    int addon_cream = 2;
    int addon_latte = 3;
    int coffeeType = 0;
    int addon = 0;
    int addmore;
    int qty;
    public void orderACoffee() {
        Scanner sc = new Scanner(System.in);
        while(true){
            System.out.println("Please select a type of coffee");
            System.out.println("1.Espresso \n2.Cappucino  \n3.Latte ");
            coffeeType = sc.nextInt();
            System.out.println(coffeeType);
            System.out.println("Please select the preferred add-on 1.Milk 2.Cream 3.Latte");
            addon = sc.nextInt();
            System.out.println("Please select the preferred qty");
            qty = sc.nextInt();
            //generateABill(coffeeType,addon,qty);
            System.out.println("Do you want to add more to the cart if so please press 1 else press 0");
            addmore= sc.nextInt();
            if (addmore==0){
                generateABill(coffeeType,addon,qty);
                break;
            }
            generateABill(coffeeType,addon,qty);
        }




    }
    public void cartItems(String coffeeType,int price ){
        total_amount = total_amount + price;
        bill = bill.concat(coffeeType + price + "\n");
        if (addmore==0){
            System.out.println("-----------Bill details-------------");
            System.out.println(bill);
            System.out.println("Your total amount is " + total_amount);
            System.out.println("------------THANK YOU---------------");
        }


    }
    public void generateABill(int coffeeType,int addon,int qty ) {

        if (coffeeType == 1) {
            if (addon == 1) {
                cartItems("Your bill of espresso with milk is:" , (qty * espresso_with_milk));
            } else if (addon == 2) {
                cartItems("Your bill of espresso with cream is:", (qty * espresso_with_cream));
            } else {
                cartItems("Your bill of espresso with latte is:" , (qty* espresso_with_latte));

            }
        } else if (coffeeType == 2) {
            if (addon == 1) {
                cartItems("Your bill of cappucinno with milk is:" ,(qty* cappucinno_with_milk));
            } else if (addon == 2) {
                cartItems("Your bill of cappucinno with cream is:" ,(qty* cappucinno_with_cream));
            } else {
                cartItems("Your bill of cappucinno with latte is:" ,(qty* cappucinno_with_latte));

            }

        } else {
            if (addon == 1) {
                cartItems("Your bill of latte with milk is:" ,(qty* latte_with_milk));
            } else if (addon == 2) {
                cartItems("Your bill of latte with cream is:" ,(qty* latte_with_cream));
            } else {
                cartItems("Your bill of latte with latte is:" ,(qty* latte_with_latte));


            }
        }
    }


}
