public class Menu extends CoffeeTypes{
    //Inherited a class
    public static void main(String[] args) {
        CoffeeTypes ct = new CoffeeTypes();
        ct.orderACoffee();
    }
}
